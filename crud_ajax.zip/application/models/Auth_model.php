<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth_model extends CI_Model {

	public function registrasi($data){
		$this->db->insert('tbl_admin',$data);
	}
	public function login($username,$password){
		$query = $this->db->get_where('tbl_admin',array('username' => $username,'password' => $password));
		if($query->num_rows() >0){
			return 1;
		}else{
			return 0;
		}
	}

}

/* End of file Auth_model.php */
/* Location: ./application/models/Auth_model.php */